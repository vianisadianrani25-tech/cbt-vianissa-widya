<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;
use Illuminate\Support\Facades\Gate;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     */
    public function register(): void
    {
        //
    }

    public function boot(): void
    {
        // Gate sederhana untuk melihat laporan
        Gate::before(function ($user, $ability) {
            return $user->hasRole('admin') ? true : null;

        });
    }
}